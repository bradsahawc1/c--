//
// Created by Cameron Bradshaw on 3/15/2021.
//

#ifndef CLASSESANDSINGLETON_MAIN_H
#define CLASSESANDSINGLETON_MAIN_H
#include <vector>
#include "Grade.h"
#include "Student.h"

int main();
void destroyStudent(Student &stu);

#endif //CLASSESANDSINGLETON_MAIN_H
